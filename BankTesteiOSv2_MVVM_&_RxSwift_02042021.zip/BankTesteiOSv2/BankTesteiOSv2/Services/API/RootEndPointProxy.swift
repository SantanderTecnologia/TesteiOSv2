//
//  RootEndPointProxy.swift
//  BankTesteiOSv2
//
//  Created by LeandroLee on 24/03/21.
//

import Foundation

class RootEndPointProxy
{
    static let rootEndpoint = "https://bank-app-test.herokuapp.com/api/"
}
